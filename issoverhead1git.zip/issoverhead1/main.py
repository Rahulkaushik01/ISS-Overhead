import requests
from datetime import datetime, timedelta
import smtplib
import time

MY_EMAIL = "kaushikrahul725@gmail.com"
MY_PASSWORD = "something"
MY_LAT = 26.912434
MY_LONG = 75.787270

def is_iss_overhead():
    response = requests.get(url="http://api.open-notify.org/iss-now.json")
    response.raise_for_status()
    data = response.json()

    iss_latitude = float(data["iss_position"]["latitude"])
    iss_longitude = float(data["iss_position"]["longitude"])

    if MY_LAT-5 <= iss_latitude <= MY_LAT+5 and MY_LONG-5 <= iss_longitude <= MY_LONG+5:
        return True

def is_night():
    parameters = {
        "lat": MY_LAT,
        "lng": MY_LONG,
        "formatted": 0,
    }
    response = requests.get("https://api.sunrise-sunset.org/json", params=parameters)
    response.raise_for_status()
    data = response.json()

    sunrise_utc = datetime.fromisoformat(data["results"]["sunrise"])
    sunset_utc = datetime.fromisoformat(data["results"]["sunset"])

    # Convert UTC to IST (UTC+5:30)
    sunrise_ist = sunrise_utc + timedelta(hours=5, minutes=30)
    sunset_ist = sunset_utc + timedelta(hours=5, minutes=30)

    time_now_ist = datetime.utcnow() + timedelta(hours=5, minutes=30)

    if time_now_ist.hour >= sunset_ist.hour or time_now_ist.hour <= sunrise_ist.hour:
        return True

while True:
    time.sleep(60)
    if is_iss_overhead() and is_night():
        with smtplib.SMTP("smtp.gmail.com") as connection:
            connection.starttls()
            connection.login(MY_EMAIL, MY_PASSWORD)
            connection.sendmail(
                from_addr=MY_EMAIL,
                to_addrs="arunkaushik110@gmail.com",
                msg="Subject:Look Up👆\n\nThe ISS is above you in the sky."
            )
